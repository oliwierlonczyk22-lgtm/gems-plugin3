package pl.gem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.DragonFireball;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LargeFireball;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.entity.WitherSkull;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class GemPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final int GEM_SLOT = 4;

    public enum Ability {
        // ruch
        DASH("Dash", NamedTextColor.AQUA, Material.PRISMARINE_CRYSTALS, 30, "Szybki zryw do przodu"),
        DOUBLE_JUMP("Double Jump", NamedTextColor.WHITE, Material.QUARTZ, 30, "Podskok w powietrzu"),
        ROCKET("Rocket", NamedTextColor.RED, Material.FIREWORK_STAR, 35, "Wystrzeliwuje cię wysoko w górę"),
        BLINK("Blink", NamedTextColor.DARK_PURPLE, Material.CHORUS_FRUIT, 35, "Teleport 8 bloków przed siebie"),
        SWAP("Swap", NamedTextColor.GREEN, Material.EMERALD, 40, "Zamienia się miejscami z celem"),
        GRAPPLE("Grapple", NamedTextColor.DARK_GREEN, Material.SLIME_BALL, 30, "Przyciąga cię do miejsca, na które patrzysz"),
        ENDER_PEARL("Pearl Throw", NamedTextColor.DARK_PURPLE, Material.ENDER_EYE, 30, "Rzuca perłę endermana"),
        // atak
        WIND_BURST("Wind Burst", NamedTextColor.GREEN, Material.BREEZE_ROD, 32, "Wystrzeliwuje ładunek wiatru"),
        FIREBALL("Fireball", NamedTextColor.GOLD, Material.BLAZE_POWDER, 45, "Kula ognia z wybuchem jak TNT"),
        WARDEN_BLAST("Warden Blast", NamedTextColor.DARK_AQUA, Material.ECHO_SHARD, 50, "Sonic boom jak Warden"),
        METEOR("Meteor", NamedTextColor.GOLD, Material.MAGMA_CREAM, 60, "Meteor spada z nieba w cel"),
        LIGHTNING("Lightning", NamedTextColor.YELLOW, Material.GLOWSTONE_DUST, 45, "Piorun w cel"),
        SLAM("Ground Slam", NamedTextColor.RED, Material.IRON_NUGGET, 40, "Fala uderzeniowa odrzucająca wrogów"),
        UPDRAFT("Updraft", NamedTextColor.WHITE, Material.FEATHER, 40, "Wyrzuca pobliskich wrogów w powietrze"),
        ARROW_RAIN("Arrow Rain", NamedTextColor.GRAY, Material.FLINT, 50, "Deszcz strzał w cel"),
        WITHER_SKULL("Wither Skull", NamedTextColor.DARK_GRAY, Material.COAL, 45, "Wystrzeliwuje czaszkę withera"),
        DRAGON_FIREBALL("Dragon Fireball", NamedTextColor.LIGHT_PURPLE, Material.DRAGON_BREATH, 55, "Smocza kula z trującą chmurą"),
        LIFE_DRAIN("Life Drain", NamedTextColor.DARK_RED, Material.FERMENTED_SPIDER_EYE, 45, "Kradnie życie pobliskim wrogom"),
        // kontrola
        SHRINK("Shrink", NamedTextColor.LIGHT_PURPLE, Material.AMETHYST_SHARD, 55, "Zmniejsza pobliskich na 6s"),
        FREEZE("Freeze", NamedTextColor.AQUA, Material.SNOWBALL, 50, "Mrozi wrogów w pobliżu"),
        WEB_TRAP("Web Trap", NamedTextColor.WHITE, Material.STRING, 45, "Oplątuje wrogów pajęczyną"),
        FLASHBANG("Flashbang", NamedTextColor.YELLOW, Material.GOLD_NUGGET, 40, "Oślepia i podświetla wrogów"),
        GRAVITY_WELL("Gravity Well", NamedTextColor.DARK_PURPLE, Material.CRYING_OBSIDIAN, 55, "Wciąga wrogów do ciebie przez 3s"),
        TOXIC_CLOUD("Toxic Cloud", NamedTextColor.GREEN, Material.SPIDER_EYE, 50, "Trująca chmura w celu"),
        // wsparcie
        HEAL("Heal", NamedTextColor.LIGHT_PURPLE, Material.GHAST_TEAR, 60, "Leczy 4 serca"),
        SHIELD("Shield", NamedTextColor.BLUE, Material.LAPIS_LAZULI, 60, "Dodatkowe serca i odporność"),
        VANISH("Vanish", NamedTextColor.GRAY, Material.GLASS_PANE, 50, "Niewidzialność i szybkość na 5s"),
        BERSERK("Berserk", NamedTextColor.DARK_RED, Material.REDSTONE, 55, "Siła i szybkość na 8s"),
        WOLF_PACK("Wolf Pack", NamedTextColor.GRAY, Material.BONE, 60, "Przywołuje 3 wilki na 20s"),
        IRON_GUARDIAN("Iron Guardian", NamedTextColor.WHITE, Material.IRON_INGOT, 60, "Przywołuje golema na 30s");

        final String display;
        final TextColor color;
        final Material material;
        final int cooldown;
        final String desc;

        Ability(String display, TextColor color, Material material, int cooldown, String desc) {
            this.display = display;
            this.color = color;
            this.material = material;
            this.cooldown = cooldown;
            this.desc = desc;
        }
    }

    static class GemMenu implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private NamespacedKey gemKey;
    private NamespacedKey equipKey;
    private double dropChance;
    private File dropFile;
    private final Random rnd = new Random();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, BukkitTask> readyTasks = new HashMap<>();
    private final Set<UUID> flightGranted = new HashSet<>();
    private final Map<UUID, Double> shrunk = new HashMap<>();
    private final Set<Ability> dropped = EnumSet.noneOf(Ability.class);

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dropChance = getConfig().getDouble("drop-chance-percent", 3.0) / 100.0;
        dropFile = new File(getDataFolder(), "dropped.yml");
        loadDropped();
        gemKey = new NamespacedKey(this, "gem_type");
        equipKey = new NamespacedKey(this, "equipped_gem");
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("gem").setExecutor(this);
        getCommand("gem").setTabCompleter(this);
        for (Player p : Bukkit.getOnlinePlayers()) {
            updateFlight(p);
        }
    }

    @Override
    public void onDisable() {
        for (Map.Entry<UUID, Double> en : shrunk.entrySet()) {
            if (Bukkit.getEntity(en.getKey()) instanceof LivingEntity le) {
                AttributeInstance at = le.getAttribute(Attribute.SCALE);
                if (at != null) at.setBaseValue(en.getValue());
            }
        }
        shrunk.clear();
        for (UUID id : new ArrayList<>(flightGranted)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.setAllowFlight(false);
                p.setFlying(false);
            }
        }
        flightGranted.clear();
    }

    // ---------- Pula unikalnych dropów ----------

    private void loadDropped() {
        dropped.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dropFile);
        for (String s : y.getStringList("dropped")) {
            Ability a = parse(s);
            if (a != null) dropped.add(a);
        }
    }

    private void saveDropped() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> names = new ArrayList<>();
        for (Ability a : dropped) names.add(a.name());
        y.set("dropped", names);
        try {
            y.save(dropFile);
        } catch (IOException ex) {
            getLogger().warning("Nie udało się zapisać dropped.yml: " + ex.getMessage());
        }
    }

    // ---------- Itemy ----------

    private Component txt(String s, TextColor c) {
        return Component.text(s, c).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack createGem(Ability a) {
        ItemStack it = new ItemStack(a.material);
        ItemMeta m = it.getItemMeta();
        m.displayName(txt("Kryształ: " + a.display, a.color));
        m.lore(List.of(
                txt(a.desc, NamedTextColor.GRAY),
                txt("Aktywacja: 2x spacja", NamedTextColor.DARK_GRAY),
                txt("Cooldown: " + a.cooldown + "s", NamedTextColor.DARK_GRAY),
                txt("Załóż w menu /gem", NamedTextColor.DARK_GRAY)));
        m.setEnchantmentGlintOverride(true);
        m.setMaxStackSize(1);
        m.getPersistentDataContainer().set(gemKey, PersistentDataType.STRING, a.name());
        it.setItemMeta(m);
        return it;
    }

    private Ability getAbility(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String s = it.getItemMeta().getPersistentDataContainer().get(gemKey, PersistentDataType.STRING);
        return parse(s);
    }

    private Ability parse(String s) {
        if (s == null) return null;
        try {
            return Ability.valueOf(s.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private Ability getEquipped(Player p) {
        return parse(p.getPersistentDataContainer().get(equipKey, PersistentDataType.STRING));
    }

    // ---------- Drop ----------

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        LivingEntity ent = e.getEntity();
        if (ent instanceof Player) return;
        if (ent.getKiller() == null) return;
        if (rnd.nextDouble() >= dropChance) return;
        List<Ability> remaining = new ArrayList<>();
        for (Ability a : Ability.values()) {
            if (!dropped.contains(a)) remaining.add(a);
        }
        if (remaining.isEmpty()) return;
        Ability pick = remaining.get(rnd.nextInt(remaining.size()));
        dropped.add(pick);
        saveDropped();
        e.getDrops().add(createGem(pick));
        Bukkit.broadcast(Component.text("Ktoś znalazł kryształ: ", NamedTextColor.GOLD)
                .append(Component.text(pick.display, pick.color)));
    }

    // ---------- Komenda i menu ----------

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] args) {
        if (args.length == 0) {
            if (!(s instanceof Player p)) {
                s.sendMessage("Tylko dla graczy.");
                return true;
            }
            openMenu(p);
            return true;
        }
        if (args[0].equalsIgnoreCase("list")) {
            s.sendMessage(Component.text("Umiejętności:", NamedTextColor.GOLD));
            for (Ability a : Ability.values()) {
                s.sendMessage(Component.text(" - " + a.display + " (" + a.cooldown + "s): " + a.desc, a.color));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("pool")) {
            if (!s.hasPermission("gem.admin")) {
                s.sendMessage(Component.text("Brak uprawnień.", NamedTextColor.RED));
                return true;
            }
            int total = Ability.values().length;
            s.sendMessage(Component.text("Wypadło " + dropped.size() + "/" + total, NamedTextColor.GOLD));
            for (Ability a : Ability.values()) {
                boolean d = dropped.contains(a);
                s.sendMessage(Component.text(" " + (d ? "[wypadł] " : "[wolny]  ") + a.display,
                        d ? NamedTextColor.DARK_GRAY : a.color));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("reset")) {
            if (!s.hasPermission("gem.admin")) {
                s.sendMessage(Component.text("Brak uprawnień.", NamedTextColor.RED));
                return true;
            }
            dropped.clear();
            saveDropped();
            s.sendMessage(Component.text("Pula dropów zresetowana - każdy kryształ może wypaść jeszcze raz.", NamedTextColor.GREEN));
            return true;
        }
        if (args[0].equalsIgnoreCase("give")) {
            if (!s.hasPermission("gem.admin")) {
                s.sendMessage(Component.text("Brak uprawnień.", NamedTextColor.RED));
                return true;
            }
            if (args.length < 2) {
                s.sendMessage(Component.text("Użycie: /gem give <ability> [gracz]", NamedTextColor.RED));
                return true;
            }
            Ability a = parse(args[1]);
            if (a == null) {
                s.sendMessage(Component.text("Nie ma takiej umiejętności. Sprawdź /gem list", NamedTextColor.RED));
                return true;
            }
            Player target = null;
            if (args.length >= 3) target = Bukkit.getPlayer(args[2]);
            else if (s instanceof Player p) target = p;
            if (target == null) {
                s.sendMessage(Component.text("Nie znaleziono gracza.", NamedTextColor.RED));
                return true;
            }
            Map<Integer, ItemStack> left = target.getInventory().addItem(createGem(a));
            for (ItemStack it : left.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), it);
            }
            s.sendMessage(Component.text("Dano kryształ " + a.display + " graczowi " + target.getName(), NamedTextColor.GREEN));
            return true;
        }
        s.sendMessage(Component.text("Użycie: /gem [give <ability> [gracz] | list | pool | reset]", NamedTextColor.RED));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = s.hasPermission("gem.admin");
        if (args.length == 1) {
            out.add("list");
            if (admin) {
                out.add("give");
                out.add("pool");
                out.add("reset");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give") && admin) {
            for (Ability a : Ability.values()) out.add(a.name().toLowerCase());
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give") && admin) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String last = args[args.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }

    private void openMenu(Player p) {
        GemMenu h = new GemMenu();
        Inventory inv = Bukkit.createInventory(h, 9, Component.text("Twój kryształ"));
        h.inv = inv;
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.displayName(Component.text(" "));
        filler.setItemMeta(fm);
        for (int i = 0; i < 9; i++) {
            if (i != GEM_SLOT) inv.setItem(i, filler);
        }
        Ability eq = getEquipped(p);
        if (eq != null) inv.setItem(GEM_SLOT, createGem(eq));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GemMenu)) return;
        ClickType ct = e.getClick();
        if (ct.isShiftClick() || ct == ClickType.NUMBER_KEY || ct == ClickType.SWAP_OFFHAND
                || ct == ClickType.DOUBLE_CLICK) {
            e.setCancelled(true);
            return;
        }
        if (e.getClickedInventory() != null && e.getClickedInventory().equals(e.getView().getTopInventory())) {
            if (e.getSlot() != GEM_SLOT) {
                e.setCancelled(true);
                return;
            }
            ItemStack cursor = e.getCursor();
            if (cursor != null && !cursor.getType().isAir() && getAbility(cursor) == null) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof GemMenu)) return;
        for (int slot : e.getRawSlots()) {
            if (slot < 9) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof GemMenu)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        ItemStack it = e.getInventory().getItem(GEM_SLOT);
        Ability a = getAbility(it);
        if (a != null) {
            p.getPersistentDataContainer().set(equipKey, PersistentDataType.STRING, a.name());
            p.sendMessage(Component.text("Wyposażono: " + a.display + " (2x spacja)", a.color));
        } else {
            if (it != null && !it.getType().isAir()) {
                p.getInventory().addItem(it).values()
                        .forEach(x -> p.getWorld().dropItemNaturally(p.getLocation(), x));
            }
            if (getEquipped(p) != null) {
                p.sendMessage(Component.text("Zdjęto kryształ.", NamedTextColor.GRAY));
            }
            p.getPersistentDataContainer().remove(equipKey);
        }
        updateFlight(p);
    }

    // ---------- 2x spacja ----------

    private boolean survivalLike(Player p) {
        GameMode gm = p.getGameMode();
        return gm != GameMode.CREATIVE && gm != GameMode.SPECTATOR;
    }

    private boolean onCooldown(Player p) {
        Long u = cooldowns.get(p.getUniqueId());
        return u != null && u > System.currentTimeMillis();
    }

    /**
     * Latanie (potrzebne do wykrycia 2x spacji) jest włączone TYLKO gdy gem jest
     * gotowy do użycia. Na czas cooldownu jest wyłączone, więc spamowanie spacji nie
     * pozwala latać.
     */
    private void updateFlight(Player p) {
        if (!survivalLike(p)) return;
        UUID id = p.getUniqueId();
        boolean has = getEquipped(p) != null;
        if (has && !onCooldown(p)) {
            p.setAllowFlight(true);
            flightGranted.add(id);
        } else {
            if (flightGranted.remove(id)) {
                p.setAllowFlight(false);
                p.setFlying(false);
            }
            if (has && onCooldown(p)) scheduleReady(p);
        }
    }

    private void scheduleReady(Player p) {
        UUID id = p.getUniqueId();
        BukkitTask old = readyTasks.remove(id);
        if (old != null) old.cancel();
        Long until = cooldowns.get(id);
        if (until == null) return;
        long ticks = Math.max(1L, (until - System.currentTimeMillis()) / 50L) + 1L;
        BukkitTask t = Bukkit.getScheduler().runTaskLater(this, () -> {
            readyTasks.remove(id);
            Player q = Bukkit.getPlayer(id);
            if (q == null) return;
            updateFlight(q);
            Ability a = getEquipped(q);
            if (a != null && !onCooldown(q)) {
                q.sendActionBar(Component.text(a.display + " gotowy!", NamedTextColor.GREEN));
            }
        }, ticks);
        readyTasks.put(id, t);
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player p = e.getPlayer();
        if (!survivalLike(p) || !e.isFlying()) return;
        if (getEquipped(p) == null) return;
        e.setCancelled(true);
        p.setFlying(false);
        trigger(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        updateFlight(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (flightGranted.remove(p.getUniqueId()) && survivalLike(p)) {
            p.setAllowFlight(false);
        }
        BukkitTask t = readyTasks.remove(p.getUniqueId());
        if (t != null) t.cancel();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> updateFlight(p), 2L);
    }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> updateFlight(p), 1L);
    }

    // ---------- Umiejętności ----------

    private void trigger(Player p) {
        Ability a = getEquipped(p);
        if (a == null) return;
        if (onCooldown(p)) {
            long left = cooldowns.get(p.getUniqueId()) - System.currentTimeMillis();
            p.sendActionBar(Component.text(a.display + " - cooldown " + (left / 1000 + 1) + "s", NamedTextColor.RED));
            updateFlight(p);
            return;
        }
        cooldowns.put(p.getUniqueId(), System.currentTimeMillis() + a.cooldown * 1000L);
        boolean ok = use(p, a);
        if (!ok) cooldowns.remove(p.getUniqueId());
        else p.sendActionBar(Component.text(a.display + "!", a.color));
        updateFlight(p);
    }

    private boolean fail(Player p, String msg) {
        p.sendActionBar(Component.text(msg, NamedTextColor.RED));
        return false;
    }

    private void snd(Player p, Sound s) {
        p.getWorld().playSound(p.getLocation(), s, 1f, 1f);
    }

    private List<LivingEntity> near(Player p, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity le : p.getLocation().getNearbyLivingEntities(r)) {
            if (!le.equals(p)) out.add(le);
        }
        return out;
    }

    private Location targetPoint(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true, 0.5,
                en -> !en.equals(p) && en instanceof LivingEntity);
        return r == null ? null : r.getHitPosition().toLocation(p.getWorld());
    }

    private boolean use(Player p, Ability a) {
        World w = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();

        switch (a) {
            case DASH -> {
                Vector d = dir.clone().setY(0);
                if (d.lengthSquared() < 1e-4) d = new Vector(0, 0, 1);
                d.normalize().multiply(1.8).setY(0.25);
                p.setVelocity(d);
                w.spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.05);
                snd(p, Sound.ENTITY_ENDER_DRAGON_FLAP);
            }
            case DOUBLE_JUMP -> {
                Vector v = dir.clone().multiply(0.3);
                v.setY(0.9);
                p.setVelocity(v);
                p.setFallDistance(0f);
                w.spawnParticle(Particle.CLOUD, p.getLocation(), 12, 0.3, 0.05, 0.3, 0.02);
                snd(p, Sound.ENTITY_ENDER_DRAGON_FLAP);
            }
            case ROCKET -> {
                p.setVelocity(new Vector(dir.getX() * 0.4, 1.9, dir.getZ() * 0.4));
                p.setFallDistance(0f);
                w.spawnParticle(Particle.FLAME, p.getLocation(), 30, 0.3, 0.1, 0.3, 0.05);
                snd(p, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH);
            }
            case BLINK -> {
                RayTraceResult r = w.rayTraceBlocks(eye, dir, 8, FluidCollisionMode.NEVER, true);
                Location dest;
                if (r == null) {
                    dest = eye.clone().add(dir.clone().multiply(8));
                } else {
                    dest = r.getHitPosition().toLocation(w).subtract(dir.clone().multiply(0.6));
                }
                dest.subtract(0, p.getEyeHeight(), 0);
                dest.setYaw(p.getLocation().getYaw());
                dest.setPitch(p.getLocation().getPitch());
                if (!dest.getBlock().isPassable() || !dest.clone().add(0, 1, 0).getBlock().isPassable()) {
                    return fail(p, "Brak miejsca na teleport");
                }
                w.spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.5);
                p.teleport(dest);
                w.spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.5);
                snd(p, Sound.ENTITY_ENDERMAN_TELEPORT);
            }
            case SWAP -> {
                RayTraceResult r = w.rayTraceEntities(eye, dir, 30, 0.6,
                        en -> !en.equals(p) && en instanceof LivingEntity);
                if (r == null || r.getHitEntity() == null) return fail(p, "Brak celu");
                LivingEntity t = (LivingEntity) r.getHitEntity();
                Location mine = p.getLocation();
                Location theirs = t.getLocation();
                p.teleport(theirs);
                t.teleport(mine);
                w.spawnParticle(Particle.PORTAL, mine.add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.5);
                w.spawnParticle(Particle.PORTAL, theirs.add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.5);
                snd(p, Sound.ENTITY_ENDERMAN_TELEPORT);
            }
            case GRAPPLE -> {
                Location t = targetPoint(p, 35);
                if (t == null) return fail(p, "Brak celu");
                Vector v = t.toVector().subtract(p.getLocation().toVector());
                double dist = v.length();
                if (dist < 1) return fail(p, "Za blisko");
                v.normalize().multiply(Math.min(2.5, 0.6 + dist * 0.1));
                v.setY(v.getY() + 0.3);
                p.setVelocity(v);
                p.setFallDistance(0f);
                snd(p, Sound.ENTITY_ENDER_DRAGON_FLAP);
            }
            case ENDER_PEARL -> {
                p.launchProjectile(EnderPearl.class);
                snd(p, Sound.ENTITY_ENDER_PEARL_THROW);
            }
            case WIND_BURST -> {
                p.launchProjectile(WindCharge.class, dir.clone().multiply(1.5));
                snd(p, Sound.ENTITY_WIND_CHARGE_THROW);
            }
            case FIREBALL -> {
                LargeFireball f = p.launchProjectile(LargeFireball.class, dir.clone().multiply(1.2));
                f.setYield(4f); // moc wybuchu TNT
                f.setIsIncendiary(false);
                snd(p, Sound.ENTITY_BLAZE_SHOOT);
            }
            case WARDEN_BLAST -> {
                Set<LivingEntity> hit = new HashSet<>();
                for (int i = 1; i <= 16; i++) {
                    Location l = eye.clone().add(dir.clone().multiply(i));
                    if (!l.getBlock().isPassable()) break;
                    w.spawnParticle(Particle.SONIC_BOOM, l, 1, 0, 0, 0, 0);
                    for (LivingEntity le : l.getNearbyLivingEntities(1.2)) {
                        if (le.equals(p) || !hit.add(le)) continue;
                        le.damage(12, p);
                        Vector kb = dir.clone().multiply(0.8);
                        kb.setY(0.3);
                        le.setVelocity(kb);
                    }
                }
                snd(p, Sound.ENTITY_WARDEN_SONIC_BOOM);
            }
            case METEOR -> {
                Location t = targetPoint(p, 45);
                if (t == null) return fail(p, "Brak celu");
                Location from = t.clone().add(0, 22, 0);
                w.spawn(from, LargeFireball.class, f -> {
                    f.setShooter(p);
                    f.setYield(3f);
                    f.setIsIncendiary(false);
                    f.setDirection(new Vector(0, -1, 0));
                    f.setVelocity(new Vector(0, -1.5, 0));
                });
                snd(p, Sound.ENTITY_BLAZE_SHOOT);
            }
            case LIGHTNING -> {
                Location t = targetPoint(p, 40);
                if (t == null) return fail(p, "Brak celu");
                w.strikeLightning(t);
            }
            case SLAM -> {
                for (LivingEntity le : near(p, 5)) {
                    le.damage(7, p);
                    Vector kb = le.getLocation().toVector().subtract(p.getLocation().toVector());
                    kb.setY(0);
                    if (kb.lengthSquared() > 1e-4) kb.normalize().multiply(1.2);
                    kb.setY(0.6);
                    le.setVelocity(kb);
                }
                w.spawnParticle(Particle.EXPLOSION, p.getLocation(), 3, 1.5, 0.1, 1.5, 0);
                snd(p, Sound.ENTITY_GENERIC_EXPLODE);
            }
            case UPDRAFT -> {
                for (LivingEntity le : near(p, 6)) {
                    le.setVelocity(new Vector(0, 1.3, 0));
                    w.spawnParticle(Particle.CLOUD, le.getLocation(), 15, 0.3, 0.1, 0.3, 0.05);
                }
                snd(p, Sound.ENTITY_ENDER_DRAGON_FLAP);
            }
            case ARROW_RAIN -> {
                Location t = targetPoint(p, 40);
                if (t == null) return fail(p, "Brak celu");
                for (int i = 0; i < 24; i++) {
                    final Location from = t.clone().add((rnd.nextDouble() - 0.5) * 8, 18, (rnd.nextDouble() - 0.5) * 8);
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        Arrow ar = w.spawnArrow(from, new Vector(0, -1, 0), 1.8f, 4f);
                        ar.setShooter(p);
                        ar.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                    }, i * 3L);
                }
                snd(p, Sound.ENTITY_ARROW_SHOOT);
            }
            case WITHER_SKULL -> {
                p.launchProjectile(WitherSkull.class, dir.clone().multiply(1.5));
                snd(p, Sound.ENTITY_WITHER_SHOOT);
            }
            case DRAGON_FIREBALL -> {
                p.launchProjectile(DragonFireball.class, dir.clone().multiply(1.0));
                snd(p, Sound.ENTITY_ENDER_DRAGON_GROWL);
            }
            case LIFE_DRAIN -> {
                List<LivingEntity> targets = near(p, 5);
                if (targets.isEmpty()) return fail(p, "Brak wrogów w pobliżu");
                double total = 0;
                for (LivingEntity le : targets) {
                    le.damage(5, p);
                    total += 5;
                    w.spawnParticle(Particle.HEART, le.getLocation().add(0, 1.5, 0), 3, 0.3, 0.3, 0.3, 0);
                }
                AttributeInstance mh = p.getAttribute(Attribute.MAX_HEALTH);
                double max = mh == null ? 20 : mh.getValue();
                p.setHealth(Math.min(max, p.getHealth() + total * 0.6));
                snd(p, Sound.ENTITY_EVOKER_CAST_SPELL);
            }
            case SHRINK -> {
                for (LivingEntity le : near(p, 6)) {
                    AttributeInstance at = le.getAttribute(Attribute.SCALE);
                    if (at == null || shrunk.containsKey(le.getUniqueId())) continue;
                    double orig = at.getBaseValue();
                    UUID id = le.getUniqueId();
                    shrunk.put(id, orig);
                    at.setBaseValue(orig * 0.4);
                    w.spawnParticle(Particle.WITCH, le.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.02);
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        AttributeInstance a2 = le.getAttribute(Attribute.SCALE);
                        if (a2 != null) a2.setBaseValue(orig);
                        shrunk.remove(id);
                    }, 120L);
                }
                snd(p, Sound.ENTITY_EVOKER_CAST_SPELL);
            }
            case FREEZE -> {
                for (LivingEntity le : near(p, 6)) {
                    le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 4));
                    le.setFreezeTicks(200);
                    w.spawnParticle(Particle.SNOWFLAKE, le.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.02);
                }
                w.spawnParticle(Particle.SNOWFLAKE, p.getLocation().add(0, 1, 0), 40, 3, 0.5, 3, 0.02);
                snd(p, Sound.ENTITY_PLAYER_LEVELUP);
            }
            case WEB_TRAP -> {
                int count = 0;
                for (LivingEntity le : near(p, 7)) {
                    Block b = le.getLocation().getBlock();
                    if (!b.getType().isAir()) continue;
                    b.setType(Material.COBWEB);
                    count++;
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        if (b.getType() == Material.COBWEB) b.setType(Material.AIR);
                    }, 100L);
                }
                if (count == 0) return fail(p, "Brak celów");
                snd(p, Sound.ENTITY_EVOKER_CAST_SPELL);
            }
            case FLASHBANG -> {
                for (LivingEntity le : near(p, 10)) {
                    le.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0));
                    le.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 160, 0));
                }
                w.spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 60, 2, 1, 2, 0.1);
                snd(p, Sound.ENTITY_GENERIC_EXPLODE);
            }
            case GRAVITY_WELL -> {
                int[] n = {0};
                Bukkit.getScheduler().runTaskTimer(this, task -> {
                    if (!p.isOnline() || n[0]++ >= 15) {
                        task.cancel();
                        return;
                    }
                    for (LivingEntity le : near(p, 9)) {
                        Vector v = p.getLocation().toVector().subtract(le.getLocation().toVector());
                        if (v.lengthSquared() < 1) continue;
                        v.normalize().multiply(0.7);
                        v.setY(0.15);
                        le.setVelocity(v);
                    }
                    w.spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 40, 3, 1, 3, 0.2);
                }, 0L, 4L);
                snd(p, Sound.ENTITY_ENDER_DRAGON_GROWL);
            }
            case TOXIC_CLOUD -> {
                Location t = targetPoint(p, 25);
                if (t == null) return fail(p, "Brak celu");
                w.spawn(t, AreaEffectCloud.class, c -> {
                    c.setRadius(4f);
                    c.setDuration(200);
                    c.setSource(p);
                    c.setColor(Color.GREEN);
                    c.addCustomEffect(new PotionEffect(PotionEffectType.POISON, 80, 1), true);
                });
                snd(p, Sound.ENTITY_EVOKER_CAST_SPELL);
            }
            case HEAL -> {
                AttributeInstance mh = p.getAttribute(Attribute.MAX_HEALTH);
                double max = mh == null ? 20 : mh.getValue();
                p.setHealth(Math.min(max, p.getHealth() + 8));
                w.spawnParticle(Particle.HEART, p.getLocation().add(0, 1.5, 0), 8, 0.4, 0.3, 0.4, 0);
                snd(p, Sound.ENTITY_PLAYER_LEVELUP);
            }
            case SHIELD -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 0));
                w.spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.02);
                snd(p, Sound.ENTITY_PLAYER_LEVELUP);
            }
            case VANISH -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 1));
                w.spawnParticle(Particle.SMOKE, p.getLocation().add(0, 1, 0), 25, 0.3, 0.6, 0.3, 0.02);
                snd(p, Sound.ENTITY_ENDERMAN_TELEPORT);
            }
            case BERSERK -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 160, 1));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 1));
                w.spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.03);
                snd(p, Sound.ENTITY_ENDER_DRAGON_GROWL);
            }
            case WOLF_PACK -> {
                for (int i = 0; i < 3; i++) {
                    Wolf wolf = w.spawn(p.getLocation(), Wolf.class, wf -> {
                        wf.setTamed(true);
                        wf.setOwner(p);
                    });
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        if (wolf.isValid()) wolf.remove();
                    }, 400L);
                }
                snd(p, Sound.ENTITY_EVOKER_CAST_SPELL);
            }
            case IRON_GUARDIAN -> {
                IronGolem g = w.spawn(p.getLocation(), IronGolem.class, gg -> gg.setPlayerCreated(true));
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    if (g.isValid()) g.remove();
                }, 600L);
                snd(p, Sound.ENTITY_EVOKER_CAST_SPELL);
            }
        }
        return true;
    }
}
